package edu.mum.cs.cs425.prodmgmt;

public class ProductMgmtApp {

}
